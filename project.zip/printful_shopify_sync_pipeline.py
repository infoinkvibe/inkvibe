"""
Batch POD pipeline: local images -> Printful products -> Shopify sync

What this scaffold does:
1. Loads a local folder of artwork images
2. Loads a config of target product templates / rules
3. Queries Printful catalog and variant metadata
4. Validates whether each image can fit each product placement
5. Generates resized artwork exports for placements
6. Creates/syncs products through Printful and/or Shopify

This is a production-oriented scaffold, not a copy/paste finished app.
You will need to fill in a few Printful endpoint details for the exact
catalog/placement endpoints you choose to use.
"""

from __future__ import annotations
from dotenv import load_dotenv
load_dotenv()
import json
import logging
import math
import os
import pathlib
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple

import requests
from PIL import Image, ImageOps


# -----------------------------
# Configuration
# -----------------------------

PRINTFUL_API_BASE = os.getenv("PRINTFUL_API_BASE", "https://api.printful.com")
SHOPIFY_STORE_DOMAIN = os.getenv("SHOPIFY_STORE_DOMAIN", "your-store.myshopify.com")
SHOPIFY_API_VERSION = os.getenv("SHOPIFY_API_VERSION", "2025-10")
SHOPIFY_GRAPHQL_URL = f"https://{SHOPIFY_STORE_DOMAIN}/admin/api/{SHOPIFY_API_VERSION}/graphql.json"

PRINTFUL_API_KEY = os.getenv("PRINTFUL_API_KEY", "")
SHOPIFY_ADMIN_TOKEN = os.getenv("SHOPIFY_ADMIN_TOKEN", "")

IMAGE_DIR = pathlib.Path(os.getenv("IMAGE_DIR", "./images"))
EXPORT_DIR = pathlib.Path(os.getenv("EXPORT_DIR", "./exports"))
STATE_PATH = pathlib.Path(os.getenv("STATE_PATH", "./state.json"))

DEFAULT_TAGS = ["print-on-demand", "printful"]
DEFAULT_VENDOR = "Printful"
DEFAULT_PRODUCT_STATUS = "DRAFT"  # ACTIVE / DRAFT in Shopify GraphQL


# -----------------------------
# Models
# -----------------------------

@dataclass
class Artwork:
    slug: str
    src_path: pathlib.Path
    title: str
    description_html: str
    tags: List[str]
    image_width: int
    image_height: int
    dpi_hint: Optional[int] = None


@dataclass
class PlacementRequirement:
    placement_name: str
    width_px: int
    height_px: int
    file_type: str = "png"
    allow_upscale: bool = False
    transparent_background_required: bool = False
    padding_pct: float = 0.0


@dataclass
class ProductTemplate:
    key: str
    printful_product_id: int
    title_pattern: str
    description_pattern: str
    enabled_colors: List[str] = field(default_factory=list)
    enabled_sizes: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    placements: List[PlacementRequirement] = field(default_factory=list)
    shopify_product_type: str = "Apparel"
    publish_to_shopify: bool = True
    push_via_printful_store_sync: bool = True


@dataclass
class PreparedArtwork:
    artwork: Artwork
    template: ProductTemplate
    placement: PlacementRequirement
    export_path: pathlib.Path
    width_px: int
    height_px: int


# -----------------------------
# Utilities
# -----------------------------

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("pod-pipeline")


def slugify(value: str) -> str:
    value = value.lower().strip()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def load_json(path: pathlib.Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: pathlib.Path, data: Any) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


# -----------------------------
# HTTP clients
# -----------------------------

class PrintfulClient:
    def __init__(self, api_key: str):
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        })

    def get(self, path: str, **params: Any) -> Dict[str, Any]:
        r = self.session.get(f"{PRINTFUL_API_BASE}{path}", params=params, timeout=60)
        r.raise_for_status()
        return r.json()

    def post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        r = self.session.post(f"{PRINTFUL_API_BASE}{path}", json=payload, timeout=60)
        r.raise_for_status()
        return r.json()

    def catalog_product(self, product_id: int) -> Dict[str, Any]:
        return self.get(f"/products/{product_id}")

    def catalog_variant(self, variant_id: int) -> Dict[str, Any]:
        return self.get(f"/products/variant/{variant_id}")

    def create_sync_product(self, store_id: int, payload: Dict[str, Any]) -> Dict[str, Any]:
        return self.post(f"/store/products", payload)


class ShopifyClient:
    def __init__(self, admin_token: str):
        self.session = requests.Session()
        self.session.headers.update({
            "X-Shopify-Access-Token": admin_token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        })

    def graphql(self, query: str, variables: Dict[str, Any]) -> Dict[str, Any]:
        r = self.session.post(
            SHOPIFY_GRAPHQL_URL,
            json={"query": query, "variables": variables},
            timeout=60,
        )
        r.raise_for_status()
        data = r.json()
        if data.get("errors"):
            raise RuntimeError(f"Shopify GraphQL errors: {data['errors']}")
        return data["data"]

    def staged_upload_image(self, file_path: pathlib.Path, mime_type: str = "image/png") -> str:
        mutation = """
        mutation stagedUploadsCreate($input: [StagedUploadInput!]!) {
          stagedUploadsCreate(input: $input) {
            stagedTargets {
              url
              resourceUrl
              parameters { name value }
            }
            userErrors { field message }
          }
        }
        """
        variables = {
            "input": [{
                "filename": file_path.name,
                "mimeType": mime_type,
                "resource": "IMAGE",
                "httpMethod": "POST",
                "fileSize": str(file_path.stat().st_size),
            }]
        }
        data = self.graphql(mutation, variables)["stagedUploadsCreate"]
        errors = data.get("userErrors") or []
        if errors:
            raise RuntimeError(f"Shopify staged upload error: {errors}")
        target = data["stagedTargets"][0]

        files = {"file": (file_path.name, file_path.read_bytes(), mime_type)}
        form_data = {p["name"]: p["value"] for p in target["parameters"]}
        upload_response = requests.post(target["url"], data=form_data, files=files, timeout=120)
        upload_response.raise_for_status()
        return target["resourceUrl"]

    def create_product(self, title: str, description_html: str, vendor: str, tags: List[str], product_type: str, status: str) -> str:
        mutation = """
        mutation productCreate($product: ProductCreateInput!) {
          productCreate(product: $product) {
            product { id title }
            userErrors { field message }
          }
        }
        """
        variables = {
            "product": {
                "title": title,
                "descriptionHtml": description_html,
                "vendor": vendor,
                "productType": product_type,
                "tags": tags,
                "status": status,
            }
        }
        data = self.graphql(mutation, variables)["productCreate"]
        if data.get("userErrors"):
            raise RuntimeError(f"Shopify productCreate errors: {data['userErrors']}")
        return data["product"]["id"]

    def bulk_create_variants(self, product_id: str, variants: List[Dict[str, Any]]) -> List[str]:
        mutation = """
        mutation productVariantsBulkCreate($productId: ID!, $variants: [ProductVariantsBulkInput!]!) {
          productVariantsBulkCreate(productId: $productId, variants: $variants) {
            productVariants { id title }
            userErrors { field message }
          }
        }
        """
        data = self.graphql(mutation, {"productId": product_id, "variants": variants})["productVariantsBulkCreate"]
        if data.get("userErrors"):
            raise RuntimeError(f"Shopify productVariantsBulkCreate errors: {data['userErrors']}")
        return [v["id"] for v in data["productVariants"]]


# -----------------------------
# Core image prep
# -----------------------------

def discover_artworks(image_dir: pathlib.Path) -> List[Artwork]:
    supported = {".png", ".jpg", ".jpeg", ".webp"}
    artworks: List[Artwork] = []

    for path in sorted(image_dir.glob("**/*")):
        if path.suffix.lower() not in supported or not path.is_file():
            continue

        with Image.open(path) as im:
            width, height = im.size

        stem = path.stem.replace("_", " ").replace("-", " ").strip()
        title = stem.title()
        artworks.append(
            Artwork(
                slug=slugify(path.stem),
                src_path=path,
                title=title,
                description_html=f"<p>{title}</p>",
                tags=[],
                image_width=width,
                image_height=height,
            )
        )

    return artworks


def validate_artwork_for_placement(artwork: Artwork, placement: PlacementRequirement) -> Tuple[bool, str]:
    too_small = artwork.image_width < placement.width_px or artwork.image_height < placement.height_px
    if too_small and not placement.allow_upscale:
        return False, (
            f"image too small ({artwork.image_width}x{artwork.image_height}) for "
            f"placement {placement.placement_name} ({placement.width_px}x{placement.height_px})"
        )
    return True, "ok"


def prepare_artwork_export(artwork: Artwork, template: ProductTemplate, placement: PlacementRequirement, export_dir: pathlib.Path) -> PreparedArtwork:
    export_dir.mkdir(parents=True, exist_ok=True)
    valid, reason = validate_artwork_for_placement(artwork, placement)
    if not valid:
        raise ValueError(reason)

    export_path = export_dir / template.key / f"{artwork.slug}-{placement.placement_name}.png"
    export_path.parent.mkdir(parents=True, exist_ok=True)

    with Image.open(artwork.src_path) as im:
        im = ImageOps.exif_transpose(im)
        im = im.convert("RGBA")

        target_w = placement.width_px
        target_h = placement.height_px

        scale = max(target_w / im.width, target_h / im.height)
        if scale > 1 and not placement.allow_upscale:
            raise ValueError("upscale required but disabled")

        resized = im.resize((math.ceil(im.width * scale), math.ceil(im.height * scale)), Image.LANCZOS)
        left = max(0, (resized.width - target_w) // 2)
        top = max(0, (resized.height - target_h) // 2)
        cropped = resized.crop((left, top, left + target_w, top + target_h))
        cropped.save(export_path, "PNG")

    return PreparedArtwork(
        artwork=artwork,
        template=template,
        placement=placement,
        export_path=export_path,
        width_px=target_w,
        height_px=target_h,
    )


# -----------------------------
# Product mapping
# -----------------------------

def load_templates(config_path: pathlib.Path) -> List[ProductTemplate]:
    raw = load_json(config_path, [])
    templates: List[ProductTemplate] = []
    for row in raw:
        templates.append(
            ProductTemplate(
                key=row["key"],
                printful_product_id=row["printful_product_id"],
                title_pattern=row.get("title_pattern", "{artwork_title}"),
                description_pattern=row.get("description_pattern", "<p>{artwork_title}</p>"),
                enabled_colors=row.get("enabled_colors", []),
                enabled_sizes=row.get("enabled_sizes", []),
                tags=row.get("tags", []),
                shopify_product_type=row.get("shopify_product_type", "Apparel"),
                publish_to_shopify=row.get("publish_to_shopify", True),
                push_via_printful_store_sync=row.get("push_via_printful_store_sync", True),
                placements=[PlacementRequirement(**p) for p in row.get("placements", [])],
            )
        )
    return templates


def build_title(template: ProductTemplate, artwork: Artwork) -> str:
    return template.title_pattern.format(artwork_title=artwork.title).strip()


def build_description(template: ProductTemplate, artwork: Artwork) -> str:
    return template.description_pattern.format(artwork_title=artwork.title).strip()


def choose_variants_from_catalog(catalog_product: Dict[str, Any], template: ProductTemplate) -> List[Dict[str, Any]]:
    variants = catalog_product.get("result", {}).get("variants", [])
    chosen: List[Dict[str, Any]] = []

    for v in variants:
        color = str(v.get("color", "")).strip()
        size = str(v.get("size", "")).strip()

        color_ok = not template.enabled_colors or color in template.enabled_colors
        size_ok = not template.enabled_sizes or size in template.enabled_sizes
        if color_ok and size_ok:
            chosen.append(v)

    return chosen


# -----------------------------
# Sync flows
# -----------------------------

def create_in_shopify_only(
    shopify: ShopifyClient,
    artwork: Artwork,
    template: ProductTemplate,
    prepared_assets: List[PreparedArtwork],
    variant_rows: List[Dict[str, Any]],
) -> Dict[str, Any]:
    title = build_title(template, artwork)
    description_html = build_description(template, artwork)
    tags = list(dict.fromkeys(DEFAULT_TAGS + artwork.tags + template.tags))

    product_id = shopify.create_product(
        title=title,
        description_html=description_html,
        vendor=DEFAULT_VENDOR,
        tags=tags,
        product_type=template.shopify_product_type,
        status=DEFAULT_PRODUCT_STATUS,
    )

    media_urls = []
    for asset in prepared_assets:
        media_urls.append(shopify.staged_upload_image(asset.export_path))

    # This example keeps variant creation simple; expand with price, SKU, inventory policy, and media associations.
    variants_input = []
    for v in variant_rows:
        option_values = []
        if v.get("color"):
            option_values.append({"name": str(v["color"]), "optionName": "Color"})
        if v.get("size"):
            option_values.append({"name": str(v["size"]), "optionName": "Size"})

        variants_input.append({
            "optionValues": option_values,
            "price": str(v.get("retail_price") or v.get("price") or "0.00"),
            "inventoryPolicy": "CONTINUE",
            "taxable": True,
        })

    variant_ids = shopify.bulk_create_variants(product_id, variants_input)
    return {"shopify_product_id": product_id, "shopify_variant_ids": variant_ids, "media_urls": media_urls}


def create_in_printful_for_connected_store(
    printful: PrintfulClient,
    store_id: int,
    artwork: Artwork,
    template: ProductTemplate,
    prepared_assets: List[PreparedArtwork],
    variant_rows: List[Dict[str, Any]],
) -> Dict[str, Any]:
    title = build_title(template, artwork)
    description_html = build_description(template, artwork)
    tags = list(dict.fromkeys(DEFAULT_TAGS + artwork.tags + template.tags))

    sync_variants = []
    for variant in variant_rows:
        files = []
        for asset in prepared_assets:
            files.append({
                "type": asset.placement.placement_name,
                "url": f"file://{asset.export_path.resolve()}"  # replace with hosted URL in real use
            })

        sync_variants.append({
            "retail_price": str(variant.get("retail_price") or variant.get("price") or "0.00"),
            "variant_id": variant["id"],
            "files": files,
        })

    payload = {
        "sync_product": {
            "name": title,
            "thumbnail": None,
            "is_ignored": False,
        },
        "sync_variants": sync_variants,
    }

    # Depending on your store setup, Printful can push this directly to Shopify.
    return printful.create_sync_product(store_id, payload)


# -----------------------------
# Runner
# -----------------------------

def run(config_path: pathlib.Path, store_id: Optional[int]) -> None:
    if not PRINTFUL_API_KEY:
        raise RuntimeError("Missing PRINTFUL_API_KEY")
    if not SHOPIFY_ADMIN_TOKEN:
        logger.warning("SHOPIFY_ADMIN_TOKEN missing. Shopify-only sync path disabled.")

    templates = load_templates(config_path)
    artworks = discover_artworks(IMAGE_DIR)
    state = load_json(STATE_PATH, {"processed": {}})

    printful = PrintfulClient(PRINTFUL_API_KEY)
    shopify = ShopifyClient(SHOPIFY_ADMIN_TOKEN) if SHOPIFY_ADMIN_TOKEN else None

    for artwork in artworks:
        if artwork.slug in state["processed"]:
            logger.info("Skipping already processed artwork: %s", artwork.slug)
            continue

        logger.info("Processing artwork: %s", artwork.src_path.name)
        state["processed"][artwork.slug] = {"products": []}

        for template in templates:
            logger.info("  Template: %s", template.key)
            catalog_product = printful.catalog_product(template.printful_product_id)
            variant_rows = choose_variants_from_catalog(catalog_product, template)
            if not variant_rows:
                logger.info("    No matching variants after color/size filters")
                continue

            prepared_assets: List[PreparedArtwork] = []
            placement_failed = False
            for placement in template.placements:
                try:
                    prepared_assets.append(prepare_artwork_export(artwork, template, placement, EXPORT_DIR))
                except Exception as exc:
                    placement_failed = True
                    logger.warning("    Placement failed (%s): %s", placement.placement_name, exc)
                    break

            if placement_failed:
                continue

            result: Dict[str, Any] = {}
            if template.push_via_printful_store_sync and store_id is not None:
                try:
                    result = create_in_printful_for_connected_store(
                        printful=printful,
                        store_id=store_id,
                        artwork=artwork,
                        template=template,
                        prepared_assets=prepared_assets,
                        variant_rows=variant_rows,
                    )
                except Exception as exc:
                    logger.exception("    Printful sync failed: %s", exc)
                    result = {"error": str(exc)}
            elif template.publish_to_shopify and shopify is not None:
                try:
                    result = create_in_shopify_only(
                        shopify=shopify,
                        artwork=artwork,
                        template=template,
                        prepared_assets=prepared_assets,
                        variant_rows=variant_rows,
                    )
                except Exception as exc:
                    logger.exception("    Shopify publish failed: %s", exc)
                    result = {"error": str(exc)}
            else:
                result = {"status": "prepared_only"}

            state["processed"][artwork.slug]["products"].append({
                "template": template.key,
                "result": result,
            })
            save_json(STATE_PATH, state)
            time.sleep(0.5)

    logger.info("Done")


if __name__ == "__main__":
    config_path = pathlib.Path(os.getenv("TEMPLATES_CONFIG", "./product_templates.json"))
    store_id_env = os.getenv("PRINTFUL_STORE_ID")
    run(config_path=config_path, store_id=int(store_id_env) if store_id_env else None)
