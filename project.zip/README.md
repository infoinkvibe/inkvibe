\# InkVibeAuto



Automates Printful product creation from local artwork.



Pipeline:



images -> resize -> product template -> Printful -> Shopify



Tech:

\- Python

\- Pillow

\- Printful API

\- Shopify GraphQL

